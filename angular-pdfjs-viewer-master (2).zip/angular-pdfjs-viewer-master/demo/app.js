angular.module('app', ['pdfjsViewer']);

angular.module('app').controller('AppCtrl', function ($scope, $http, $timeout) {
    var url = 'example.pdf';
    var str;

    $scope.pdf = {
        src: url,  // get pdf source from a URL that points to a pdf
        data: null // get pdf source from raw data of a pdf
    };

    getPdfAsArrayBuffer(url).then(function (response) {
        $scope.pdf.data = new Uint8Array(response.data);
    }, function (err) {
        console.log('failed to get pdf as binary:', err);
    });

    function getPdfAsArrayBuffer (url) {
        return $http.get(url, {
            responseType: 'arraybuffer',
            headers: {
                'foo': 'bar'
            }
        });
    }
    $(document).ready(function(){
        $('input[type="file"]').change(function(e){
           $scope.pdf.src = e.target.files[0].name;
           document.getElementById('hide').style.display = 'none';
           document.getElementById('show').style.display = 'none';
        });
    });

    $scope.doc =function(){
      str = $scope.pdf.src;
      if(str.substr(str.indexOf(".") + 1) == "pdf")
      {
      document.getElementById('hide').style.display = '';
      }
      else
      {
        document.getElementById('show').style.display = '';
      }
    }

});
